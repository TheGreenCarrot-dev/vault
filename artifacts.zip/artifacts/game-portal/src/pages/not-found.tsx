import { Link } from "wouter";
import { Layout } from "@/components/layout";
import { AlertCircle } from "lucide-react";

export default function NotFound() {
  return (
    <Layout>
      <div className="min-h-[70vh] flex flex-col items-center justify-center text-center p-6">
        <div className="w-24 h-24 rounded-full bg-destructive/10 flex items-center justify-center mb-8">
          <AlertCircle className="w-12 h-12 text-destructive" />
        </div>
        
        <h1 className="text-6xl font-display font-black text-white mb-4 tracking-tighter">404</h1>
        <h2 className="text-2xl font-bold text-white/80 mb-6">Zone Not Found</h2>
        
        <p className="text-muted-foreground max-w-md mb-10">
          The coordinates you entered lead to empty space. The game or page you're looking for doesn't exist.
        </p>
        
        <Link 
          href="/" 
          className="px-8 py-4 rounded-xl font-bold text-lg text-white bg-primary shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
        >
          Return to Arcade
        </Link>
      </div>
    </Layout>
  );
}
