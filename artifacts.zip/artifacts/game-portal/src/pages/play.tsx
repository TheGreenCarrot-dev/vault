import { useParams, useLocation } from "wouter";
import { useGetGame } from "@workspace/api-client-react";
import { ArrowLeft, Maximize2, Share2, Download, AlertTriangle } from "lucide-react";
import { useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function Play() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  const { data: game, isLoading, error } = useGetGame(parseInt(id!));
  
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [iframeLoading, setIframeLoading] = useState(true);
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const mouseTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({ title: "Link Copied!", description: "Game URL copied to clipboard." });
  };

  const handleDownload = () => {
    if (!game) return;
    const a = document.createElement('a');
    a.href = `/api/storage${game.objectPath}`;
    a.download = `${game.title.replace(/\s+/g, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen().catch(err => {
        toast({ title: "Error", description: "Fullscreen not supported", variant: "destructive" });
      });
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  // Hide controls after 2.5s of inactivity when in fullscreen
  const handleMouseMove = () => {
    if (!isFullscreen) return;
    
    setControlsVisible(true);
    if (mouseTimerRef.current) clearTimeout(mouseTimerRef.current);
    
    mouseTimerRef.current = setTimeout(() => {
      setControlsVisible(false);
    }, 2500);
  };

  if (isLoading) {
    return (
      <div className="w-screen h-screen bg-background flex flex-col items-center justify-center text-white">
        <div className="w-16 h-16 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-6" />
        <h2 className="text-2xl font-display font-bold animate-pulse">Loading Arcade Core...</h2>
      </div>
    );
  }

  if (error || !game) {
    return (
      <div className="w-screen h-screen bg-background flex flex-col items-center justify-center text-white p-6 text-center">
        <AlertTriangle className="w-20 h-20 text-destructive mb-6" />
        <h2 className="text-3xl font-display font-bold mb-4">Game Not Found</h2>
        <p className="text-muted-foreground mb-8 max-w-md">
          The game you are looking for does not exist or has been removed from the portal.
        </p>
        <button 
          onClick={() => setLocation('/')}
          className="px-8 py-3 rounded-xl bg-white/10 hover:bg-white/20 font-bold transition-colors"
        >
          Return to Arcade
        </button>
      </div>
    );
  }

  // Construct iframe src URL correctly based on API assumptions
  const gameUrl = `/api/storage${game.objectPath}`;

  return (
    <div 
      ref={containerRef}
      className={`w-screen h-screen bg-black flex flex-col overflow-hidden relative ${isFullscreen && !controlsVisible ? 'cursor-none' : ''}`}
      onMouseMove={handleMouseMove}
    >
      {/* Top Navigation / Controls overlay */}
      <AnimatePresence>
        {(!isFullscreen || controlsVisible) && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`absolute top-0 left-0 right-0 z-50 p-4 transition-all duration-300 ${
              isFullscreen ? 'bg-gradient-to-b from-black/80 to-transparent pt-6' : 'bg-background border-b border-white/5'
            }`}
          >
            <div className="max-w-7xl mx-auto flex items-center justify-between">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => isFullscreen ? toggleFullscreen() : setLocation('/')}
                  className="p-2 rounded-xl bg-white/5 hover:bg-white/20 text-white transition-colors"
                  title="Back"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <div>
                  <h1 className="text-lg md:text-xl font-display font-bold text-white line-clamp-1">
                    {game.title}
                  </h1>
                  {!isFullscreen && game.description && (
                    <p className="text-xs text-muted-foreground hidden sm:block line-clamp-1">
                      {game.description}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-2 sm:gap-3">
                <button 
                  onClick={handleShare}
                  className="p-2 sm:px-4 sm:py-2 rounded-xl bg-white/5 hover:bg-white/20 text-white font-medium flex items-center gap-2 transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Share</span>
                </button>
                <button 
                  onClick={handleDownload}
                  className="p-2 sm:px-4 sm:py-2 rounded-xl bg-white/5 hover:bg-white/20 text-white font-medium flex items-center gap-2 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span className="hidden sm:inline">Download</span>
                </button>
                <div className="w-px h-6 bg-white/10 mx-1 hidden sm:block" />
                <button 
                  onClick={toggleFullscreen}
                  className="p-2 rounded-xl bg-primary hover:bg-primary/80 text-white shadow-lg shadow-primary/20 transition-colors"
                  title="Toggle Fullscreen"
                >
                  <Maximize2 className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Game Iframe */}
      <div className={`flex-1 w-full relative ${!isFullscreen ? 'pt-[72px]' : ''}`}>
        {/* Loading spinner — hidden once iframe fires onLoad */}
        {iframeLoading && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-black gap-4">
            <div className="relative w-16 h-16">
              <div className="absolute inset-0 rounded-full border-4 border-white/5" />
              <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-primary animate-spin" />
              <div className="absolute inset-1 rounded-full border-2 border-transparent border-t-accent animate-spin [animation-duration:0.7s] [animation-direction:reverse]" />
            </div>
            <p className="text-sm text-white/30 font-medium tracking-widest uppercase animate-pulse">
              Loading game...
            </p>
          </div>
        )}
        <iframe
          ref={iframeRef}
          src={gameUrl}
          className="absolute inset-0 w-full h-full border-none bg-black"
          title={`Play ${game.title}`}
          sandbox="allow-scripts allow-same-origin allow-pointer-lock"
          allow="fullscreen"
          onLoad={() => setIframeLoading(false)}
        />
      </div>
    </div>
  );
}
