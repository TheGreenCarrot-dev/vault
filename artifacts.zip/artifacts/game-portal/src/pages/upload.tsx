import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { UploadCloud, Heading, X, AlertCircle, Lock, ImagePlus } from "lucide-react";
import { useGameUpload } from "@/hooks/use-game-upload";
import { useToast } from "@/hooks/use-toast";
import { formatBytes } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

function AdminGate({ onUnlock }: { onUnlock: () => void }) {
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [checking, setChecking] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setChecking(true);
    setError("");

    try {
      const res = await fetch("/api/admin/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      if (res.ok) {
        sessionStorage.setItem("gcg_admin", "true");
        onUnlock();
      } else {
        setError("Invalid access code. Only TheGreenCarrot can upload games.");
      }
    } catch {
      setError("Connection error. Please try again.");
    } finally {
      setChecking(false);
    }
  };

  return (
    <Layout>
      <div className="max-w-md mx-auto py-20 flex flex-col items-center text-center">
        <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-6 shadow-xl shadow-primary/20">
          <Lock className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-3xl font-display font-black text-white mb-3">
          Admin Access Only
        </h1>
        <p className="text-muted-foreground mb-8 max-w-sm">
          Game uploads are restricted to TheGreenCarrot. Enter your access code to continue.
        </p>

        <form onSubmit={handleSubmit} className="w-full space-y-4">
          <input
            type="password"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Enter access code..."
            className="w-full px-5 py-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium text-center tracking-widest"
            autoFocus
          />
          {error && (
            <p className="text-sm text-destructive font-medium">{error}</p>
          )}
          <button
            type="submit"
            disabled={!code || checking}
            className="w-full py-4 rounded-xl font-bold text-lg text-white bg-gradient-to-r from-primary to-accent shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 hover:-translate-y-0.5"
          >
            {checking ? "Verifying..." : "Unlock Upload"}
          </button>
        </form>
      </div>
    </Layout>
  );
}

export default function Upload() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { uploadGame, isUploading, progress } = useGameUpload();

  const [isAdmin, setIsAdmin] = useState(sessionStorage.getItem("gcg_admin") === "true");

  const [file, setFile] = useState<File | null>(null);
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);

  if (!isAdmin) {
    return <AdminGate onUnlock={() => setIsAdmin(true)} />;
  }

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") setDragActive(true);
    else if (e.type === "dragleave") setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.name.endsWith('.html')) {
        setFile(droppedFile);
        if (!title) setTitle(droppedFile.name.replace('.html', '').replace(/[-_]/g, ' '));
      } else {
        toast({ title: "Invalid file type", description: "Please upload an HTML file (.html)", variant: "destructive" });
      }
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      if (!title) setTitle(selectedFile.name.replace('.html', '').replace(/[-_]/g, ' '));
    }
  };

  const handleThumbnailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const img = e.target.files[0];
      setThumbnail(img);
      const reader = new FileReader();
      reader.onload = (ev) => setThumbnailPreview(ev.target?.result as string);
      reader.readAsDataURL(img);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    if (!title.trim()) {
      toast({ title: "Validation Error", description: "Title is required", variant: "destructive" });
      return;
    }

    try {
      await uploadGame({ file, thumbnail, title, description });
      toast({ title: "Success!", description: "Game uploaded and ready to play." });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : "Something went wrong during upload.",
        variant: "destructive"
      });
    }
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto py-10 relative">
        <div className="absolute inset-0 opacity-10 pointer-events-none rounded-3xl overflow-hidden" style={{
          backgroundImage: `url(${import.meta.env.BASE_URL}images/pattern.png)`,
          backgroundSize: '200px',
        }} />

        <div className="text-center mb-10 relative z-10">
          <h1 className="text-4xl md:text-5xl font-display font-black text-white mb-4">
            PUBLISH <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent to-primary">GAME</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-xl mx-auto">
            Upload a self-contained HTML file to instantly create a playable arcade experience.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="relative z-10 space-y-8 glass-panel p-8 md:p-10 rounded-3xl shadow-2xl">

          {/* HTML File Drop */}
          <div
            className={`relative w-full h-52 rounded-2xl border-2 border-dashed transition-all duration-300 flex flex-col items-center justify-center overflow-hidden cursor-pointer ${
              dragActive
                ? "border-primary bg-primary/10 scale-[1.02]"
                : file
                  ? "border-accent/50 bg-accent/5"
                  : "border-white/20 bg-black/40 hover:border-white/40 hover:bg-white/5"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => !file && fileInputRef.current?.click()}
          >
            <input ref={fileInputRef} type="file" accept=".html" onChange={handleFileChange} className="hidden" />

            <AnimatePresence mode="wait">
              {file ? (
                <motion.div key="file" initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }} className="flex flex-col items-center">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-blue-600 flex items-center justify-center mb-3 shadow-lg shadow-accent/20">
                    <Heading className="w-7 h-7 text-white" />
                  </div>
                  <p className="text-base font-bold text-white mb-1">{file.name}</p>
                  <p className="text-sm text-accent font-medium mb-3">{formatBytes(file.size)}</p>
                  <button type="button" onClick={(e) => { e.stopPropagation(); setFile(null); setTitle(""); }} className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/50 text-white/70 hover:text-white hover:bg-white/10 transition-colors text-sm">
                    <X className="w-3.5 h-3.5" /> Remove
                  </button>
                </motion.div>
              ) : (
                <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center pointer-events-none">
                  <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-3">
                    <UploadCloud className="w-8 h-8 text-primary" />
                  </div>
                  <p className="text-lg font-bold text-white mb-1">Drag & drop your game</p>
                  <p className="text-muted-foreground text-sm">or click to browse (.html files only)</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Thumbnail Upload */}
          <div>
            <label className="block text-sm font-semibold text-white/80 mb-3 ml-1">
              Thumbnail Image <span className="text-white/40 font-normal">(Optional)</span>
            </label>
            <div
              className="relative h-36 rounded-xl border border-dashed border-white/20 bg-black/40 hover:border-white/40 hover:bg-white/5 transition-all duration-300 flex items-center justify-center overflow-hidden cursor-pointer"
              onClick={() => thumbnailInputRef.current?.click()}
            >
              <input
                ref={thumbnailInputRef}
                type="file"
                accept="image/*"
                onChange={handleThumbnailChange}
                className="hidden"
              />
              {thumbnailPreview ? (
                <>
                  <img src={thumbnailPreview} alt="Thumbnail preview" className="absolute inset-0 w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); setThumbnail(null); setThumbnailPreview(null); }}
                      className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/70 text-white text-sm font-medium"
                    >
                      <X className="w-3.5 h-3.5" /> Remove
                    </button>
                  </div>
                </>
              ) : (
                <div className="flex flex-col items-center gap-2 pointer-events-none">
                  <ImagePlus className="w-8 h-8 text-white/30" />
                  <p className="text-sm text-white/40">Click to add a thumbnail image</p>
                </div>
              )}
            </div>
          </div>

          {/* Title & Description */}
          <div className="space-y-5">
            <div>
              <label htmlFor="title" className="block text-sm font-semibold text-white/80 mb-2 ml-1">Game Title</label>
              <input
                id="title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Epic Adventure 3000"
                className="w-full px-5 py-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all font-medium"
                required
              />
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-semibold text-white/80 mb-2 ml-1">
                Description <span className="text-white/40 font-normal">(Optional)</span>
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="A brief description of what this game is about..."
                className="w-full px-5 py-4 rounded-xl bg-black/50 border border-white/10 text-white placeholder-white/30 focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all min-h-[100px] resize-y font-medium"
              />
            </div>
          </div>

          {/* Submit */}
          <div className="pt-4 border-t border-white/10">
            {isUploading ? (
              <div className="space-y-3">
                <div className="flex justify-between text-sm font-medium">
                  <span className="text-white">Uploading & Processing...</span>
                  <span className="text-primary">{progress}%</span>
                </div>
                <div className="w-full h-3 bg-black/50 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-primary to-accent relative"
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    transition={{ ease: "circOut" }}
                  >
                    <div className="absolute inset-0 bg-white/20 animate-pulse" />
                  </motion.div>
                </div>
              </div>
            ) : (
              <button
                type="submit"
                disabled={!file}
                className="w-full py-4 rounded-xl font-bold text-lg text-white bg-gradient-to-r from-primary to-accent shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none transition-all duration-300 hover:-translate-y-1"
              >
                Publish to Arcade
              </button>
            )}
            <div className="mt-4 flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <AlertCircle className="w-4 h-4" />
              <span>Only single self-contained HTML files are supported.</span>
            </div>
          </div>
        </form>
      </div>
    </Layout>
  );
}
