import { useListGames } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";
import { GameCard } from "@/components/game-card";
import { Search, Joystick } from "lucide-react";
import { useState, useRef } from "react";
import { getFavorites } from "@/lib/favorites";

export default function Home() {
  const { data: games, isLoading, error } = useListGames();
  const [search, setSearch] = useState("");
  const arcadeRef = useRef<HTMLDivElement>(null);

  const scrollToArcade = () => {
    arcadeRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const favorites = getFavorites();

  const filtered = (games || []).filter(g =>
    g.title.toLowerCase().includes(search.toLowerCase()) ||
    (g.description && g.description.toLowerCase().includes(search.toLowerCase()))
  );

  // Favorites float to top, rest sorted by date
  const sorted = [
    ...filtered.filter(g => favorites.includes(g.id)),
    ...filtered.filter(g => !favorites.includes(g.id)),
  ];

  return (
    <Layout onArcadeClick={scrollToArcade}>
      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden mb-10 bg-black min-h-[340px] flex items-end">
        <div className="absolute inset-0">
          <img
            src={`${import.meta.env.BASE_URL}images/hero-bg.png`}
            alt=""
            className="w-full h-full object-cover opacity-40"
          />
          {/* Green left fade */}
          <div className="absolute inset-0 bg-gradient-to-r from-[hsl(148,18%,5%)] via-[hsl(148,18%,5%)]/70 to-transparent" />
          {/* Bottom fade */}
          <div className="absolute inset-0 bg-gradient-to-t from-[hsl(148,18%,5%)] via-transparent to-transparent" />
          {/* Green ambient glow */}
          <div className="absolute top-0 left-0 w-96 h-96 rounded-full bg-primary/20 blur-[100px] -translate-x-1/4 -translate-y-1/4" />
          <div className="absolute bottom-0 right-1/4 w-72 h-72 rounded-full bg-accent/15 blur-[80px]" />
        </div>

        <div className="relative z-10 px-8 pb-10 pt-16 max-w-xl">
          {/* Studio badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/15 border border-primary/25 text-primary text-xs font-bold tracking-widest uppercase mb-4">
            <span>🥕</span>
            <span>GCS Presents</span>
          </div>

          <h1 className="text-5xl md:text-6xl font-display font-black text-white leading-[0.95] mb-4">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-primary/70 text-glow">
              GCG
            </span>
            <br />
            <span className="text-white/90">Arcade</span>
          </h1>

          <p className="text-sm text-white/45 mb-6 max-w-xs leading-relaxed">
            Pure HTML games, zero installs. Click, play, share — from TheGreenCarrot's desk to your browser.
          </p>

          <div className="flex gap-3 flex-wrap mb-6">
            <button
              onClick={scrollToArcade}
              className="px-6 py-2.5 rounded-xl carrot-gradient text-white font-bold text-sm shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-0.5 transition-all duration-300"
            >
              Browse Games
            </button>
          </div>

          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input
              type="text"
              placeholder="Search games..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder-white/30 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary/50 backdrop-blur-sm transition-all"
            />
          </div>
        </div>
      </div>

      {/* Arcade Grid */}
      <div ref={arcadeRef} className="scroll-mt-20">
        <div className="mb-6 flex items-center justify-between">
          <h2 className="text-xl font-display font-bold text-white flex items-center gap-2">
            <Joystick className="w-5 h-5 text-primary" />
            The Vault
            {favorites.length > 0 && (
              <span className="text-xs font-medium text-accent bg-accent/10 border border-accent/20 px-2 py-0.5 rounded-full">
                {favorites.length} fav{favorites.length !== 1 ? "s" : ""}
              </span>
            )}
          </h2>
          <span className="text-xs text-white/30 font-medium">
            {sorted.length} {sorted.length === 1 ? 'game' : 'games'}
          </span>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-60 rounded-2xl bg-white/4 animate-pulse border border-white/5" />
            ))}
          </div>
        ) : error ? (
          <div className="p-12 text-center glass-panel rounded-3xl">
            <h3 className="text-xl font-bold text-destructive mb-2">Arcade offline</h3>
            <p className="text-white/40 text-sm">Couldn't reach the server. Try again later.</p>
          </div>
        ) : sorted.length === 0 ? (
          <div className="p-20 text-center glass-panel rounded-3xl flex flex-col items-center border-dashed border border-white/5">
            <span className="text-5xl mb-4">🥕</span>
            <h3 className="text-xl font-display font-bold text-white mb-2">
              {search ? "No matches" : "Vault is empty"}
            </h3>
            <p className="text-white/35 text-sm max-w-xs">
              {search ? "Try a different search term." : "TheGreenCarrot hasn't uploaded anything yet. Check back soon!"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 pb-20">
            {sorted.map((game, i) => (
              <GameCard key={game.id} game={game} index={i} isFavorited={favorites.includes(game.id)} />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
