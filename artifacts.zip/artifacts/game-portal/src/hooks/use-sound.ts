let ctx: AudioContext | null = null;

function getCtx(): AudioContext {
  if (!ctx) ctx = new AudioContext();
  return ctx;
}

function playTone(
  frequency: number,
  type: OscillatorType,
  duration: number,
  gain: number,
  attack = 0.005,
  decay = 0.1,
  sustain = 0.3,
  release = duration
) {
  const ac = getCtx();
  const osc = ac.createOscillator();
  const gainNode = ac.createGain();
  osc.connect(gainNode);
  gainNode.connect(ac.destination);
  osc.type = type;
  osc.frequency.setValueAtTime(frequency, ac.currentTime);
  gainNode.gain.setValueAtTime(0, ac.currentTime);
  gainNode.gain.linearRampToValueAtTime(gain, ac.currentTime + attack);
  gainNode.gain.linearRampToValueAtTime(gain * sustain, ac.currentTime + attack + decay);
  gainNode.gain.linearRampToValueAtTime(0, ac.currentTime + release);
  osc.start(ac.currentTime);
  osc.stop(ac.currentTime + release + 0.05);
}

export const sounds = {
  /** Satisfying soft "pop" for button clicks */
  click() {
    playTone(660, "sine", 0.12, 0.18, 0.003, 0.04, 0.2, 0.12);
    playTone(440, "sine", 0.12, 0.08, 0.003, 0.06, 0.1, 0.1);
  },

  /** Bright upward chime for success / save */
  success() {
    const notes = [523, 659, 784];
    notes.forEach((freq, i) => {
      setTimeout(() => playTone(freq, "sine", 0.3, 0.15, 0.005, 0.05, 0.4, 0.3), i * 80);
    });
  },

  /** Punchy low thud for delete */
  destroy() {
    playTone(120, "sawtooth", 0.2, 0.25, 0.003, 0.08, 0.1, 0.2);
    playTone(80, "sine", 0.2, 0.15, 0.003, 0.1, 0.05, 0.2);
  },

  /** Swooshing reveal chord for the splash screen */
  reveal() {
    const ac = getCtx();
    [220, 330, 440, 550].forEach((freq, i) => {
      setTimeout(() => {
        const osc = ac.createOscillator();
        const g = ac.createGain();
        osc.connect(g);
        g.connect(ac.destination);
        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, ac.currentTime);
        osc.frequency.exponentialRampToValueAtTime(freq * 2.2, ac.currentTime + 0.8);
        g.gain.setValueAtTime(0, ac.currentTime);
        g.gain.linearRampToValueAtTime(0.12, ac.currentTime + 0.05);
        g.gain.linearRampToValueAtTime(0, ac.currentTime + 0.9);
        osc.start(ac.currentTime);
        osc.stop(ac.currentTime + 1);
      }, i * 60);
    });
  },

  /** Soft sparkle when opening a modal */
  open() {
    playTone(880, "sine", 0.15, 0.1, 0.003, 0.03, 0.3, 0.15);
    setTimeout(() => playTone(1100, "sine", 0.1, 0.07, 0.003, 0.03, 0.2, 0.1), 50);
  },
};
