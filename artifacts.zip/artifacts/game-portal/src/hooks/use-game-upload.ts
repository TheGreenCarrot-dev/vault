import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRequestUploadUrl, useCreateGame } from "@workspace/api-client-react";

export function useGameUpload() {
  const queryClient = useQueryClient();
  const requestUrlMutation = useRequestUploadUrl();
  const createGameMutation = useCreateGame();

  const [isUploading, setIsUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const uploadFile = async (file: File): Promise<string> => {
    const { uploadURL, objectPath } = await requestUrlMutation.mutateAsync({
      data: {
        name: file.name,
        size: file.size,
        contentType: file.type || "application/octet-stream",
      }
    });

    const uploadResponse = await fetch(uploadURL, {
      method: "PUT",
      headers: { "Content-Type": file.type || "application/octet-stream" },
      body: file,
    });

    if (!uploadResponse.ok) throw new Error("Failed to upload file to storage.");
    return objectPath;
  };

  const uploadGame = async ({
    file,
    thumbnail,
    title,
    description,
  }: {
    file: File;
    thumbnail: File | null;
    title: string;
    description: string;
  }) => {
    setIsUploading(true);
    setProgress(10);

    try {
      // Upload the game HTML file
      const objectPath = await uploadFile(file);
      setProgress(50);

      // Optionally upload thumbnail
      let thumbnailPath: string | null = null;
      if (thumbnail) {
        thumbnailPath = await uploadFile(thumbnail);
      }
      setProgress(80);

      // Create game entry in DB
      const game = await createGameMutation.mutateAsync({
        data: {
          title,
          description,
          objectPath,
          thumbnailPath: thumbnailPath ?? undefined,
          fileSize: file.size,
        }
      });

      setProgress(100);
      queryClient.invalidateQueries({ queryKey: ["/api/games"] });
      return game;
    } catch (error) {
      throw error;
    } finally {
      setIsUploading(false);
      setTimeout(() => setProgress(0), 1000);
    }
  };

  return {
    uploadGame,
    isUploading,
    progress,
    error: requestUrlMutation.error || createGameMutation.error,
  };
}
