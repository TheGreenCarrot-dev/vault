import { useState } from "react";
import { Link, useLocation } from "wouter";
import { UploadCloud, Swords, Info } from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { sounds } from "@/hooks/use-sound";
import { AboutModal } from "@/components/about-modal";

interface LayoutProps {
  children: React.ReactNode;
  onArcadeClick?: () => void;
}

export function Layout({ children, onArcadeClick }: LayoutProps) {
  const [location] = useLocation();
  const isAdmin = sessionStorage.getItem("gcg_admin") === "true";
  const [aboutOpen, setAboutOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col relative">
      <nav className="sticky top-0 z-50 w-full glass-panel border-b-0 shadow-xl shadow-black/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2.5 group" onClick={() => sounds.click()}>
              <div className="relative flex items-center justify-center w-9 h-9 rounded-xl carrot-gradient shadow-lg shadow-primary/20 group-hover:shadow-primary/40 transition-all duration-300 group-hover:scale-105">
                <span className="text-lg leading-none">🥕</span>
              </div>
              <div className="flex flex-col leading-none gap-0.5">
                <span className="font-display font-black text-lg tracking-tight text-white">
                  GCG
                </span>
                <span className="text-[9px] text-primary/70 font-semibold tracking-[0.2em] uppercase">
                  GreenCarrotGames
                </span>
              </div>
            </Link>

            {/* Nav */}
            <div className="flex items-center gap-2">
              {location === "/" ? (
                <button
                  onClick={() => { sounds.click(); onArcadeClick?.(); }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-bold transition-all text-primary bg-primary/10 border border-primary/20"
                >
                  <Swords className="w-4 h-4" />
                  <span>Arcade</span>
                </button>
              ) : (
                <Link
                  href="/"
                  onClick={() => sounds.click()}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all text-white/50 hover:text-white hover:bg-white/5"
                >
                  <Swords className="w-4 h-4" />
                  <span>Arcade</span>
                </Link>
              )}

              {isAdmin && (
                <Link
                  href="/upload"
                  onClick={() => sounds.click()}
                  className={cn(
                    "flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-bold transition-all duration-300",
                    location === "/upload"
                      ? "bg-accent text-white shadow-lg shadow-accent/30"
                      : "carrot-gradient text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 hover:-translate-y-0.5"
                  )}
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>Publish</span>
                </Link>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="flex-1 w-full max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
          className="h-full"
        >
          {children}
        </motion.div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-white/5 bg-black/20 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex flex-col gap-2.5">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🥕</span>
                <div>
                  <span className="font-display font-black text-white text-base">GCG</span>
                  <span className="text-primary/60 text-xs ml-1.5 font-medium">by GCS</span>
                </div>
              </div>
              <p className="text-xs text-white/35 max-w-xs leading-relaxed">
                Play and share self-contained HTML games. No installs. No servers. Just click.
              </p>
            </div>

            <div className="flex flex-col gap-2">
              <h4 className="text-xs font-bold text-white/40 uppercase tracking-widest">GCS</h4>
              <div className="flex flex-col gap-1 text-xs text-white/30">
                <span>GreenCarrotStudios</span>
                <span>Founded by TheGreenCarrot</span>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <h4 className="text-xs font-bold text-white/40 uppercase tracking-widest">Nav</h4>
              <div className="flex flex-col gap-1">
                <Link href="/" className="text-xs text-white/30 hover:text-primary transition-colors">Home</Link>
                <Link href="/upload" className="text-xs text-white/30 hover:text-primary transition-colors">Publish Game</Link>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3">
            <p className="text-[11px] text-white/20">
              © {new Date().getFullYear()} GreenCarrotStudios · All rights reserved
            </p>
            <div className="flex items-center gap-2">
              <p className="text-[11px] text-white/20">Made by TheGreenCarrot</p>
              <button
                onClick={() => { sounds.open(); setAboutOpen(true); }}
                className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-[11px] text-white/35 hover:text-primary hover:bg-primary/10 hover:border-primary/20 transition-all"
                title="About the Founder"
              >
                <Info className="w-2.5 h-2.5" />
                About
              </button>
            </div>
          </div>
        </div>
      </footer>

      <AboutModal open={aboutOpen} onClose={() => setAboutOpen(false)} />
    </div>
  );
}
