import { useState, useRef } from "react";
import { X, Upload, Pencil, Image, FileCode2, Loader2 } from "lucide-react";
import { type Game, type UpdateGameBody, useUpdateGame, useRequestUploadUrl } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface EditGameModalProps {
  game: Game;
  onClose: () => void;
}

export function EditGameModal({ game, onClose }: EditGameModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const updateMutation = useUpdateGame();
  const requestUrlMutation = useRequestUploadUrl();

  const [title, setTitle] = useState(game.title);
  const [description, setDescription] = useState(game.description ?? "");
  const [newThumbnail, setNewThumbnail] = useState<File | null>(null);
  const [newGameFile, setNewGameFile] = useState<File | null>(null);
  const [clearThumbnail, setClearThumbnail] = useState(false);
  const [saving, setSaving] = useState(false);
  const thumbnailInputRef = useRef<HTMLInputElement>(null);
  const gameFileInputRef = useRef<HTMLInputElement>(null);

  const uploadFile = async (file: File, folder: "games" | "thumbnails") => {
    const { url, objectPath } = await requestUrlMutation.mutateAsync({
      data: { name: `${folder}/${Date.now()}-${file.name}`, contentType: file.type || "text/html" },
    });
    await fetch(url, {
      method: "PUT",
      headers: { "Content-Type": file.type || "text/html" },
      body: file,
    });
    return objectPath;
  };

  const handleSave = async () => {
    if (!title.trim()) {
      toast({ title: "Title required", description: "Please enter a game title.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const patch: UpdateGameBody = {
        title: title.trim(),
        description: description.trim() || undefined,
      };

      if (clearThumbnail) {
        patch.thumbnailPath = null;
      } else if (newThumbnail) {
        patch.thumbnailPath = await uploadFile(newThumbnail, "thumbnails");
      }

      if (newGameFile) {
        patch.objectPath = await uploadFile(newGameFile, "games");
      }

      await updateMutation.mutateAsync({ id: game.id, data: patch });
      queryClient.invalidateQueries({ queryKey: ["/api/games"] });
      queryClient.invalidateQueries({ queryKey: [`/api/games/${game.id}`] });
      toast({ title: "Game updated!", description: "Changes saved successfully." });
      onClose();
    } catch {
      toast({ title: "Save failed", description: "Something went wrong. Try again.", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const thumbnailPreview = newThumbnail
    ? URL.createObjectURL(newThumbnail)
    : !clearThumbnail && game.thumbnailPath
    ? `/api/storage${game.thumbnailPath}`
    : null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative z-10 w-full max-w-lg bg-[#0f0f13] border border-white/10 rounded-2xl shadow-2xl shadow-black/80 overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Pencil className="w-4 h-4 text-primary" />
            <h2 className="text-lg font-display font-bold text-white">Edit Game</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/10 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="px-6 py-5 space-y-5">

          {/* Title */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-white/50 uppercase tracking-wider">Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/20 focus:outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/30 transition-all"
              placeholder="Game title..."
            />
          </div>

          {/* Description */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-white/50 uppercase tracking-wider">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white placeholder-white/20 focus:outline-none focus:border-primary/60 focus:ring-1 focus:ring-primary/30 transition-all resize-none"
              placeholder="Short description..."
            />
          </div>

          {/* Thumbnail */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-white/50 uppercase tracking-wider">Thumbnail</label>
            <div className="flex items-center gap-3">
              <div className="w-20 h-14 rounded-xl overflow-hidden border border-white/10 bg-white/5 flex items-center justify-center flex-shrink-0">
                {thumbnailPreview ? (
                  <img src={thumbnailPreview} alt="thumbnail" className="w-full h-full object-cover" />
                ) : (
                  <Image className="w-6 h-6 text-white/20" />
                )}
              </div>
              <div className="flex flex-col gap-2 min-w-0">
                <button
                  onClick={() => thumbnailInputRef.current?.click()}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-sm text-white/70 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <Upload className="w-3.5 h-3.5" />
                  {thumbnailPreview ? "Replace image" : "Upload image"}
                </button>
                {(thumbnailPreview) && (
                  <button
                    onClick={() => { setNewThumbnail(null); setClearThumbnail(true); }}
                    className="text-xs text-destructive/70 hover:text-destructive text-left transition-colors"
                  >
                    Remove thumbnail
                  </button>
                )}
              </div>
            </div>
            <input
              ref={thumbnailInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) { setNewThumbnail(f); setClearThumbnail(false); } }}
            />
          </div>

          {/* Replace game file */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-white/50 uppercase tracking-wider">Game File</label>
            <div className="flex items-center gap-3">
              <button
                onClick={() => gameFileInputRef.current?.click()}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-white/5 border border-white/10 text-sm text-white/70 hover:text-white hover:bg-white/10 transition-colors"
              >
                <FileCode2 className="w-3.5 h-3.5" />
                {newGameFile ? newGameFile.name : "Replace .html file"}
              </button>
              {newGameFile && (
                <button onClick={() => setNewGameFile(null)} className="text-xs text-white/30 hover:text-white/60 transition-colors">
                  Cancel
                </button>
              )}
            </div>
            <input
              ref={gameFileInputRef}
              type="file"
              accept=".html,.htm"
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) setNewGameFile(f); }}
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 px-6 py-4 border-t border-white/5">
          <button
            onClick={onClose}
            disabled={saving}
            className="px-4 py-2 rounded-xl text-sm text-white/50 hover:text-white hover:bg-white/10 transition-colors disabled:opacity-40"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-5 py-2 rounded-xl text-sm font-bold bg-primary hover:bg-primary/80 text-white shadow-lg shadow-primary/20 transition-all disabled:opacity-60 flex items-center gap-2"
          >
            {saving && <Loader2 className="w-4 h-4 animate-spin" />}
            {saving ? "Saving..." : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}
