import { X, Leaf } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { sounds } from "@/hooks/use-sound";

interface AboutModalProps {
  open: boolean;
  onClose: () => void;
}

export function AboutModal({ open, onClose }: AboutModalProps) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          key="about-backdrop"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
        >
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
          <motion.div
            key="about-panel"
            className="relative z-10 w-full max-w-sm bg-[#0f0f13] border border-white/10 rounded-2xl shadow-2xl shadow-black/80 overflow-hidden"
            initial={{ opacity: 0, scale: 0.92, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 24 }}
            transition={{ type: "spring", stiffness: 320, damping: 26 }}
          >
            {/* Top accent bar */}
            <div className="h-1 w-full bg-gradient-to-r from-primary via-accent to-primary" />

            <div className="p-6">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="text-4xl">🥕</div>
                  <div>
                    <h2 className="text-lg font-display font-bold text-white leading-tight">About the Founder</h2>
                    <p className="text-xs text-white/40 tracking-wide">GreenCarrotStudios</p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-lg text-white/30 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Body */}
              <div className="rounded-xl bg-white/5 border border-white/5 p-4 space-y-3">
                <div className="flex items-center gap-2 text-sm text-white/80 font-medium">
                  <Leaf className="w-4 h-4 text-primary flex-shrink-0" />
                  <span>Founded by <span className="text-primary font-bold">TheGreenCarrot</span></span>
                </div>
                <p className="text-sm text-white/50 leading-relaxed pl-6">
                  Mission: Unblocking the web, one game at a time.
                </p>
              </div>

              <button
                onClick={onClose}
                className="mt-4 w-full py-2 rounded-xl text-sm text-white/40 hover:text-white hover:bg-white/5 transition-colors"
              >
                Close
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
