import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { sounds } from "@/hooks/use-sound";

interface SplashScreenProps {
  onDone: () => void;
}

export function SplashScreen({ onDone }: SplashScreenProps) {
  const [out, setOut] = useState(false);

  useEffect(() => {
    const t1 = setTimeout(() => sounds.reveal(), 150);
    const t2 = setTimeout(() => setOut(true), 2500);
    const t3 = setTimeout(() => onDone(), 3200);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  return (
    <AnimatePresence>
      {!out && (
        <motion.div
          key="splash"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.65, ease: "easeInOut" }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center overflow-hidden select-none"
          style={{ background: "hsl(148, 18%, 4%)" }}
        >
          {/* Background glows */}
          <motion.div
            className="absolute w-[700px] h-[700px] rounded-full blur-[140px] pointer-events-none"
            style={{ background: "hsl(142, 62%, 42%, 0.12)" }}
            animate={{ scale: [0.7, 1.2, 1], opacity: [0, 0.7, 0.3] }}
            transition={{ duration: 2.6, ease: "easeOut" }}
          />
          <motion.div
            className="absolute w-[400px] h-[400px] rounded-full blur-[100px] pointer-events-none"
            style={{ background: "hsl(25, 100%, 55%, 0.1)" }}
            animate={{ scale: [0.5, 1.3, 0.95], opacity: [0, 0.5, 0.15] }}
            transition={{ duration: 2.6, delay: 0.25, ease: "easeOut" }}
          />

          {/* Carrot bounce-in */}
          <motion.div
            className="text-[90px] mb-5 relative z-10 drop-shadow-2xl"
            initial={{ scale: 0.2, opacity: 0, rotate: -25, y: 20 }}
            animate={{ scale: 1, opacity: 1, rotate: 0, y: 0 }}
            transition={{ delay: 0.1, duration: 0.7, type: "spring", stiffness: 220, damping: 16 }}
          >
            🥕
          </motion.div>

          {/* GCS label */}
          <motion.p
            className="text-[11px] font-bold tracking-[0.35em] uppercase mb-2 relative z-10"
            style={{ color: "hsl(142, 62%, 42%, 0.6)" }}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.55, duration: 0.45 }}
          >
            GreenCarrotStudios
          </motion.p>

          {/* "Presents" */}
          <motion.h1
            className="text-3xl sm:text-4xl font-display font-black text-white relative z-10"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.75, duration: 0.45 }}
          >
            Presents
            <motion.span
              style={{ color: "hsl(25, 100%, 55%)" }}
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 1, 0, 1, 0, 1] }}
              transition={{ delay: 1.1, duration: 0.9 }}
            >
              ...
            </motion.span>
          </motion.h1>

          {/* Progress bar */}
          <motion.div
            className="absolute bottom-0 left-0 h-[3px]"
            style={{ background: "linear-gradient(90deg, hsl(142,62%,42%), hsl(25,100%,55%), hsl(142,62%,42%))" }}
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ delay: 0.15, duration: 2.3, ease: "linear" }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
