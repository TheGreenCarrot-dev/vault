import { useState } from "react";
import { Link } from "wouter";
import { Play, Download, Share2, Trash2, Pencil, Star } from "lucide-react";
import { motion } from "framer-motion";
import { type Game } from "@workspace/api-client-react";
import { getInitials, formatBytes } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useDeleteGame } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { EditGameModal } from "@/components/edit-game-modal";
import { toggleFavorite } from "@/lib/favorites";
import { sounds } from "@/hooks/use-sound";

interface GameCardProps {
  game: Game;
  index: number;
  isFavorited: boolean;
}

export function GameCard({ game, index, isFavorited: initialFav }: GameCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const deleteMutation = useDeleteGame();
  const isAdmin = sessionStorage.getItem("gcg_admin") === "true";
  const [editOpen, setEditOpen] = useState(false);
  const [fav, setFav] = useState(initialFav);

  const handleShare = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    const url = `${window.location.origin}/play/${game.id}`;
    navigator.clipboard.writeText(url);
    sounds.click();
    toast({ title: "Link copied!", description: "Share it with a friend." });
  };

  const handleDownload = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    const a = document.createElement('a');
    a.href = `/api/storage${game.objectPath}`;
    a.download = `${game.title.replace(/\s+/g, '_')}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDelete = async (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    if (confirm(`Delete "${game.title}"?`)) {
      try {
        await deleteMutation.mutateAsync({ id: game.id });
        queryClient.invalidateQueries({ queryKey: ["/api/games"] });
        sounds.destroy();
        toast({ title: "Deleted", description: `${game.title} removed from the vault.` });
      } catch {
        toast({ title: "Error", description: "Couldn't delete the game.", variant: "destructive" });
      }
    }
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    sounds.open();
    setEditOpen(true);
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.preventDefault(); e.stopPropagation();
    const nowFav = toggleFavorite(game.id);
    setFav(nowFav);
    sounds.click();
    toast({
      title: nowFav ? "Added to favorites" : "Removed from favorites",
      description: nowFav ? `${game.title} will appear at the top.` : undefined,
    });
  };

  const thumbnailUrl = game.thumbnailPath ? `/api/storage${game.thumbnailPath}` : null;

  return (
    <>
      {editOpen && <EditGameModal game={game} onClose={() => setEditOpen(false)} />}

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3, delay: index * 0.04 }}
      >
        <Link href={`/play/${game.id}`} className="block group">
          <div className={`relative h-full flex flex-col glass-panel rounded-2xl overflow-hidden transition-all duration-300 transform group-hover:-translate-y-1 ${fav ? 'box-glow border-primary/20' : 'box-glow-hover'}`}>

            {/* Favorite ribbon if starred */}
            {fav && (
              <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-primary via-accent to-primary z-30" />
            )}

            {/* Thumbnail */}
            <div className="relative h-40 w-full overflow-hidden flex items-center justify-center bg-gradient-to-br from-secondary to-background">
              {thumbnailUrl ? (
                <img
                  src={thumbnailUrl}
                  alt={`${game.title}`}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              ) : (
                <>
                  <div className="absolute top-0 right-0 -mr-8 -mt-8 w-32 h-32 rounded-full bg-primary/15 blur-2xl" />
                  <div className="absolute bottom-0 left-0 -ml-8 -mb-8 w-28 h-28 rounded-full bg-accent/15 blur-2xl" />
                  <div className="relative z-10 w-16 h-16 rounded-2xl bg-black/40 backdrop-blur border border-white/10 flex items-center justify-center transform group-hover:scale-110 transition-transform duration-500">
                    <span className="text-2xl font-display font-black text-transparent bg-clip-text bg-gradient-to-br from-white to-white/40">
                      {getInitials(game.title)}
                    </span>
                  </div>
                </>
              )}

              {thumbnailUrl && (
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300" />
              )}

              {/* Top-right admin + fav buttons */}
              <div className="absolute top-2.5 right-2.5 flex gap-1.5 z-20">
                {/* Favorite — always visible */}
                <button
                  onClick={handleFavorite}
                  className={`p-1.5 rounded-full backdrop-blur transition-all ${
                    fav
                      ? 'bg-primary/80 text-white opacity-100'
                      : 'bg-black/40 text-white/40 hover:text-primary hover:bg-primary/20 opacity-0 group-hover:opacity-100'
                  }`}
                  title={fav ? "Unfavorite" : "Favorite"}
                >
                  <Star className={`w-3.5 h-3.5 ${fav ? 'fill-white' : ''}`} />
                </button>

                {/* Admin: edit + delete */}
                {isAdmin && (
                  <>
                    <button
                      onClick={handleEdit}
                      className="p-1.5 rounded-full bg-black/40 backdrop-blur text-white/40 hover:text-primary hover:bg-primary/20 opacity-0 group-hover:opacity-100 transition-all"
                      title="Edit"
                    >
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={handleDelete}
                      disabled={deleteMutation.isPending}
                      className="p-1.5 rounded-full bg-black/40 backdrop-blur text-white/40 hover:text-destructive hover:bg-destructive/20 opacity-0 group-hover:opacity-100 transition-all"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Content */}
            <div className="p-4 flex-1 flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-base font-display font-bold text-white group-hover:text-primary transition-colors line-clamp-1 flex-1">
                  {game.title}
                </h3>
                {fav && <Star className="w-3 h-3 text-primary fill-primary flex-shrink-0 mt-0.5" />}
              </div>
              <p className="mt-1.5 text-xs text-white/40 line-clamp-2 flex-1 leading-relaxed">
                {game.description || "No description."}
              </p>
              <div className="mt-3 pt-3 border-t border-white/5 flex items-center justify-between text-[11px] text-white/25">
                <span>{formatBytes(game.fileSize)}</span>
                <span>{new Date(game.createdAt).toLocaleDateString()}</span>
              </div>
            </div>

            {/* Hover overlay */}
            <div className="absolute inset-0 bg-black/55 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-10">
              <div className="flex flex-col items-center gap-2 transform translate-y-3 group-hover:translate-y-0 transition-all duration-300">
                <div className="w-12 h-12 rounded-full carrot-gradient flex items-center justify-center text-white shadow-lg shadow-primary/40">
                  <Play className="w-5 h-5 ml-0.5" />
                </div>
                <span className="text-xs font-bold text-white tracking-widest">PLAY</span>
              </div>
            </div>

            {/* Download / Share (side buttons on hover) */}
            <div className="absolute top-1/2 left-0 right-0 -translate-y-1/2 flex justify-between px-3 opacity-0 group-hover:opacity-100 transition-all duration-300 delay-75 z-20 pointer-events-none">
              <button
                onClick={handleDownload}
                className="p-2.5 rounded-full bg-black/80 border border-white/10 text-white hover:text-primary hover:border-primary/40 pointer-events-auto shadow-xl transition-all hover:scale-110"
                title="Download"
              >
                <Download className="w-4 h-4" />
              </button>
              <button
                onClick={handleShare}
                className="p-2.5 rounded-full bg-black/80 border border-white/10 text-white hover:text-accent hover:border-accent/40 pointer-events-auto shadow-xl transition-all hover:scale-110"
                title="Share"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </Link>
      </motion.div>
    </>
  );
}
