import { Router, type IRouter } from "express";

const router: IRouter = Router();

router.post("/admin/verify", (req, res) => {
  const { code } = req.body;
  const adminCode = process.env.ADMIN_CODE;

  if (!adminCode) {
    req.log.warn("ADMIN_CODE environment variable not set");
    return res.status(500).json({ error: "Admin access not configured" });
  }

  if (code === adminCode) {
    res.json({ success: true });
  } else {
    res.status(401).json({ error: "Invalid access code" });
  }
});

export default router;
