import { Router, type IRouter } from "express";
import { db, gamesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  CreateGameBody,
  GetGameParams,
  DeleteGameParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/games", async (req, res) => {
  try {
    const games = await db.select().from(gamesTable).orderBy(gamesTable.createdAt);
    res.json(games);
  } catch (err) {
    req.log.error({ err }, "Failed to list games");
    res.status(500).json({ error: "Failed to list games" });
  }
});

router.post("/games", async (req, res) => {
  try {
    const body = CreateGameBody.parse(req.body);
    const [game] = await db
      .insert(gamesTable)
      .values({
        title: body.title,
        description: body.description ?? "",
        objectPath: body.objectPath,
        thumbnailPath: body.thumbnailPath ?? null,
        fileSize: body.fileSize,
      })
      .returning();
    res.status(201).json(game);
  } catch (err) {
    req.log.error({ err }, "Failed to create game");
    res.status(400).json({ error: "Failed to create game" });
  }
});

router.patch("/games/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { title, description, thumbnailPath, objectPath } = req.body as {
      title?: string;
      description?: string;
      thumbnailPath?: string | null;
      objectPath?: string;
    };

    const updates: Record<string, unknown> = { updatedAt: new Date() };
    if (title !== undefined) updates.title = title;
    if (description !== undefined) updates.description = description;
    if (thumbnailPath !== undefined) updates.thumbnailPath = thumbnailPath;
    if (objectPath !== undefined) updates.objectPath = objectPath;

    const [game] = await db
      .update(gamesTable)
      .set(updates)
      .where(eq(gamesTable.id, id))
      .returning();

    if (!game) return res.status(404).json({ error: "Game not found" });
    res.json(game);
  } catch (err) {
    req.log.error({ err }, "Failed to update game");
    res.status(500).json({ error: "Failed to update game" });
  }
});

router.get("/games/:id", async (req, res) => {
  try {
    const { id } = GetGameParams.parse({ id: Number(req.params.id) });
    const [game] = await db
      .select()
      .from(gamesTable)
      .where(eq(gamesTable.id, id));
    if (!game) {
      return res.status(404).json({ error: "Game not found" });
    }
    res.json(game);
  } catch (err) {
    req.log.error({ err }, "Failed to get game");
    res.status(500).json({ error: "Failed to get game" });
  }
});

router.delete("/games/:id", async (req, res) => {
  try {
    const { id } = DeleteGameParams.parse({ id: Number(req.params.id) });
    const [game] = await db
      .delete(gamesTable)
      .where(eq(gamesTable.id, id))
      .returning();
    if (!game) {
      return res.status(404).json({ error: "Game not found" });
    }
    res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete game");
    res.status(500).json({ error: "Failed to delete game" });
  }
});

export default router;
